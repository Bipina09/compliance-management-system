from django.contrib.auth.models import AbstractUser
from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models
from django.db import models
from django.utils import timezone

class CustomUserManager(BaseUserManager):
    def create_user(self, username, email, password=None, **extra_fields):
        if not email:
            raise ValueError('Users must have an email address')
        
        user = self.model(
            username=username,
            email=self.normalize_email(email),
            **extra_fields
        )
        user.set_password(password)  # This hashes the password
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)
        extra_fields.setdefault('is_active', True)  # Ensure active
        
        return self.create_user(username, email, password, **extra_fields)


class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('Admin', 'Admin'),
        ('Manager', 'Manager'),
        ('Employee', 'Employee'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='Employee')
    
    USERNAME_FIELD = 'username'
    EMAIL_FIELD = 'email'
    REQUIRED_FIELDS = ['email', 'role']
    
    objects = CustomUserManager()
    
    def __str__(self):
        return self.username
    
    def is_admin(self):
        return self.role == 'Admin'
    
    def is_manager(self):
        return self.role == 'Manager'
    
    def is_employee(self):
        return self.role == 'Employee'
    
class Policy(models.Model):
    title = models.CharField(max_length=255)
    text = models.TextField()
    file = models.FileField(upload_to='policy_files/', blank=True, null=True)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

    def delete(self, *args, **kwargs):
        # Add a flag to prevent duplicate notifications from the signal
        self._notification_already_sent = True
        super().delete(*args, **kwargs)

# Dashboard Survey Model
class SurveyResponse(models.Model):
    q1 = models.CharField(max_length=10)
    q2 = models.CharField(max_length=10)
    q3 = models.CharField(max_length=10)
    q4 = models.CharField(max_length=10)
    score = models.IntegerField(default=0)  # ✅ New field added here
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Survey on {self.submitted_at} - Score: {self.score}"

    def calculate_score(self):
        answers = [self.q1.lower(), self.q2.lower(), self.q3.lower(), self.q4.lower()]
        yes = answers.count("yes")
        no = answers.count("no")
        if yes > no:
            return 90, "Nice Work!"
        elif no > yes:
            return 30, "Critical State"
        return 50, "Need to Work On"

# model for incident reporting

class IncidentReport(models.Model):
    LOCATION_CHOICES = [
        ('branch1', 'Branch 1'),
        ('branch2', 'Branch 2'),
        ('branch3', 'Branch 3'),
    ]
    INCIDENT_TYPE_CHOICES = [
        ('cyber', 'Cyber Incident'),
        ('physical', 'Physical Incident'),
    ]
    INVESTIGATION_STATUS_CHOICES = [
        ('not-verified', 'Not Verified'),
        ('verified', 'Verified'),
        ('ongoing', 'Ongoing'),
    ]

    location = models.CharField(max_length=50, choices=LOCATION_CHOICES)
    vendor = models.CharField(max_length=100, blank=True)
    incident_title = models.CharField(max_length=200)
    incident_type = models.CharField(max_length=50, choices=INCIDENT_TYPE_CHOICES)
    investigation_status = models.CharField(max_length=50, choices=INVESTIGATION_STATUS_CHOICES)
    has_evidence = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    has_evidence = models.BooleanField(default=False)
    evidence_file = models.FileField(upload_to='incident_evidence/', blank=True, null=True)  # New field
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='created_incidents')  # New field
    last_updated = models.DateTimeField(auto_now=True)  # New field

    def __str__(self):
        return self.incident_title
    
class IncidentEditHistory(models.Model):  # New model
    incident = models.ForeignKey(IncidentReport, on_delete=models.CASCADE, related_name='edit_history')
    edited_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    edited_at = models.DateTimeField(auto_now_add=True)
    changes = models.TextField()  # Stores what was changed

    class Meta:
        ordering = ['-edited_at']

    def __str__(self):
        return f"Edit by {self.edited_by} at {self.edited_at}"
# models for training

class QuizSubmission(models.Model):
    name = models.CharField(max_length=100)
    score = models.IntegerField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.score}"
    
    

# notification 
class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    policy = models.ForeignKey('Policy', on_delete=models.CASCADE, null=True, blank=True)  # Make sure this exists
    message = models.CharField(max_length=255)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.message[:50]}"
