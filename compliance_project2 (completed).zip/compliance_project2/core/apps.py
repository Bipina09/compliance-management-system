from django.apps import AppConfig

class CoreConfig(AppConfig):  # Changed from YourAppConfig to CoreConfig
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core'

    def ready(self):
        import core.signals