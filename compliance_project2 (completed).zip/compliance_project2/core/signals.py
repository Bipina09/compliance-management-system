# core/signals.py
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from .models import Policy, Notification
import logging
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.contrib.auth import get_user_model
from .models import Notification


logger = logging.getLogger(__name__)

@receiver(post_save, sender=Policy)
def notify_model_update(sender, instance, created, **kwargs):
    if not created:  # Only notify on updates, not creations
        message = f"{sender.__name__} '{instance}' was updated"
        users = get_user_model().objects.exclude(id=instance.author.id)
        for user in users:
            Notification.objects.create(
                user=user,
                message=message
            )

     

@receiver(post_delete, sender=Policy)
def notify_model_deletion(sender, instance, **kwargs):
    message = f"{sender.__name__} '{instance}' was deleted"
    users = get_user_model().objects.exclude(id=instance.author.id)
    for user in users:
        Notification.objects.create(
            user=user,
            message=message
        )