from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('policy/', views.policy_view, name='policy'),  # GET - List policies
    path('policy/create/', views.add_policy, name='add_policy'),  # POST - Create policy
    path('training/', views.training_view, name='training'),
    path('incident/', views.incident_report_view, name='incident'),
    path('policy/view/<int:pk>/', views.view_policy, name='view_policy'),
    path('certification/', views.certification_view, name='certification'),
    path('notifications/mark-read/<int:notification_id>/', views.mark_notification_read, name='mark_notification_read'),
    path('notifications/get/', views.get_notifications, name='get_notifications'),
     path('policy/view/<int:pk>/', views.view_policy, name='view_policy'),
    path('policy/edit/<int:pk>/', views.edit_policy, name='edit_policy'),
    path('policy/delete/<int:pk>/', views.delete_policy, name='delete_policy'),
    path('incidents/', views.incident_list_view, name='incident_list'),
    path('incidents/<int:pk>/', views.incident_detail_view, name='incident_detail'),
    path('incidents/<int:pk>/edit/', views.incident_edit_view, name='incident_edit'),
    path('incident/', views.incident_report_view, name='incident'),  # For new reports
    
]