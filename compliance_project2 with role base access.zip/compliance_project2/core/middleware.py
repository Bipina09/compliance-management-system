from django.utils.deprecation import MiddlewareMixin
from django.utils.cache import add_never_cache_headers
from django.utils.deprecation import MiddlewareMixin


class DisableCacheForAuthenticatedUsers(MiddlewareMixin):
    def process_response(self, request, response):
        # Skip cache headers for these paths
        exempt_paths = [
            '/admin/',
            '/login/',
            '/register/',
            '/logout/'
        ]
        
        if (request.user.is_authenticated and 
            not any(request.path.startswith(path) for path in exempt_paths)):
            add_never_cache_headers(response)
        return response