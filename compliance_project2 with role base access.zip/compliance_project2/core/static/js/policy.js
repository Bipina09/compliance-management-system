let userRole = storedUser ? storedUser.role : null;

// Role-Based Access Control for Employees
if (userRole === "Employee") {
    createPolicyBtn.disabled = true;
    createPolicyBtn.style.cursor = "not-allowed";
    createPolicyBtn.addEventListener("click", function (event) {
        event.preventDefault();
        alert("You are not authorized to create or edit a policy.");
    });
} else {
    createPolicyBtn.addEventListener("click", function () {
        checkPolicy();
    });
}
