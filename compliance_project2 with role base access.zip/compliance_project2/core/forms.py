from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser
from .models import Policy

class RegisterForm(UserCreationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'email', 'role', 'password1', 'password2']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Limit role choices if not superuser
        if not self.initial.get('is_superuser'):
            self.fields['role'].choices = [
                ('Employee', 'Employee'),
                ('Manager', 'Manager'),
            ]

class LoginForm(AuthenticationForm):
    class Meta:
        model = CustomUser
        fields = ['username', 'password']
        
class PolicyForm(forms.ModelForm):
    class Meta:
        model = Policy
        fields = ['title', 'text', 'file']
        widgets = {
            'title': forms.TextInput(attrs={
                'placeholder': 'Enter policy title',
                'class': 'form-input'
            }),
            'text': forms.Textarea(attrs={
                'placeholder': 'Enter full policy text',
                'rows': 5,
                'class': 'form-textarea'
            }),
            'file': forms.ClearableFileInput(attrs={
                'class': 'form-file'
            }),
        }
        
from django import forms
from .models import SurveyResponse

class SurveyForm(forms.ModelForm):
    class Meta:
        model = SurveyResponse
        fields = ['q1', 'q2', 'q3', 'q4']
        widgets = {
            'q1': forms.Select(choices=[('yes', 'Yes'), ('no', 'No')]),
            'q2': forms.Select(choices=[('yes', 'Yes'), ('no', 'No')]),
            'q3': forms.Select(choices=[('yes', 'Yes'), ('no', 'No')]),
            'q4': forms.Select(choices=[('yes', 'Yes'), ('no', 'No')]),
        }

#form for incident
from django import forms
from .models import IncidentReport

class IncidentReportForm(forms.ModelForm):
    class Meta:
        model = IncidentReport
        fields = '__all__'
        widgets = {
            'vendor': forms.TextInput(attrs={'placeholder': 'Enter Vendor Name'}),
            'incident_title': forms.TextInput(attrs={'placeholder': 'Enter Title'}),
        }

#form for training
from django import forms

class TrainingQuizForm(forms.Form):
    name = forms.CharField(max_length=100, label="Your Name")
    q1 = forms.ChoiceField(choices=[('yes', 'Yes'), ('no', 'No')], widget=forms.RadioSelect, label="1. Is phishing a common cyberattack method?")
    q2 = forms.ChoiceField(choices=[('yes', 'Yes'), ('no', 'No')], widget=forms.RadioSelect, label="2. Should you share passwords with colleagues?")
    q3 = forms.ChoiceField(choices=[('yes', 'Yes'), ('no', 'No')], widget=forms.RadioSelect, label="3. Is using MFA important for security?")
