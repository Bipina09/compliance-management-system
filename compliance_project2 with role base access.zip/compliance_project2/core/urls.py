from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('policy/', views.policy_view, name='policy'),  # GET - List policies
    path('policy/create/', views.add_policy, name='add_policy'),  # POST - Create policy
    path('training/', views.training_view, name='training'),
    path('incident/', views.incident_report_view, name='incident'),
    path('policy/view/<int:pk>/', views.view_policy, name='view_policy'),
    path('certification/', views.certification_view, name='certification'),
]