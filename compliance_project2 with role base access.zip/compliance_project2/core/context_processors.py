# core/context_processors.py
def user_roles(request):
    return {
        'user_role': request.user.role if request.user.is_authenticated else None,
        'is_admin': request.user.role == 'Admin' if request.user.is_authenticated else False,
        'is_manager': request.user.role == 'Manager' if request.user.is_authenticated else False,
        'is_employee': request.user.role == 'Employee' if request.user.is_authenticated else False,
    }