from django.contrib.auth.models import AbstractUser
from django.db import models
from django.conf import settings

class CustomUser(AbstractUser):
    ROLE_CHOICES = [
        ('Admin', 'Admin'),
        ('Manager', 'Manager'),
        ('Employee', 'Employee'),
    ]
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='Employee')

class Policy(models.Model):
    title = models.CharField(max_length=255)
    text = models.TextField()
    file = models.FileField(upload_to='policy_files/', blank=True, null=True)
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

# Dashboard Survey Model
class SurveyResponse(models.Model):
    q1 = models.CharField(max_length=10)
    q2 = models.CharField(max_length=10)
    q3 = models.CharField(max_length=10)
    q4 = models.CharField(max_length=10)
    score = models.IntegerField(default=0)  # ✅ New field added here
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Survey on {self.submitted_at} - Score: {self.score}"

    def calculate_score(self):
        answers = [self.q1.lower(), self.q2.lower(), self.q3.lower(), self.q4.lower()]
        yes = answers.count("yes")
        no = answers.count("no")
        if yes > no:
            return 90, "Nice Work!"
        elif no > yes:
            return 30, "Critical State"
        return 50, "Need to Work On"

# model for incident reporting

class IncidentReport(models.Model):
    LOCATION_CHOICES = [
        ('branch1', 'Branch 1'),
        ('branch2', 'Branch 2'),
        ('branch3', 'Branch 3'),
    ]
    INCIDENT_TYPE_CHOICES = [
        ('cyber', 'Cyber Incident'),
        ('physical', 'Physical Incident'),
    ]
    INVESTIGATION_STATUS_CHOICES = [
        ('not-verified', 'Not Verified'),
        ('verified', 'Verified'),
        ('ongoing', 'Ongoing'),
    ]

    location = models.CharField(max_length=50, choices=LOCATION_CHOICES)
    vendor = models.CharField(max_length=100, blank=True)
    incident_title = models.CharField(max_length=200)
    incident_type = models.CharField(max_length=50, choices=INCIDENT_TYPE_CHOICES)
    investigation_status = models.CharField(max_length=50, choices=INVESTIGATION_STATUS_CHOICES)
    has_evidence = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.incident_title

# models for training

class QuizSubmission(models.Model):
    name = models.CharField(max_length=100)
    score = models.IntegerField()
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} - {self.score}"
