from django.urls import path
from . import views
from .views import (
    policy_view,
    training_view,
    incident_report_view,
    view_policy,
    certification_view,
    logout_view,  # ✅ Add this here
)

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
    path('policy/', views.add_policy, name='add_policy'),
    path('policy/', views.policy_view, name='policy'), 
    path('training/', views.training_view, name='training'),
    path('incident/', views.incident_report_view, name='incident'),
     path('policy/view/<int:pk>/', views.view_policy, name='view_policy'),
     path('certification/', views.certification_view, name='certification'),
    path('logout/', logout_view, name='logout'),


]
