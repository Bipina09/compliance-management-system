from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate, logout
from .forms import RegisterForm, LoginForm, PolicyForm
from .models import CustomUser, Policy
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
import os
import PyPDF2
from PyPDF2 import PdfReader

# Registration View
from django.contrib.auth.models import User

def register_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')  # must be captured
        email = request.POST.get('email')
        password = request.POST.get('password')

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        return redirect('login')
    return render(request, 'core/register.html')



# Logout View
def logout_view(request):
    logout(request)
    return redirect('login')

# Dashboard
@login_required
def dashboard_view(request):
    return render(request, 'dashboard.html')

# Policy Text Extractor
def read_file_content(file):
    if file.name.endswith('.txt'):
        return file.read().decode('utf-8', errors='ignore')
    elif file.name.endswith('.pdf'):
        try:
            reader = PdfReader(file)
            return "\n".join([page.extract_text() for page in reader.pages if page.extract_text()])
        except Exception:
            return ""
    return ""

# HIPAA Compliance Checker
def check_hipaa_compliance(text, standard_path):
    if not text.strip():
        return False
    text = text.lower()
    try:
        with open(standard_path, 'r') as f:
            hipaa_lines = [line.strip().lower() for line in f if line.strip()]
    except FileNotFoundError:
        return False

    required_matches = 0
    for clause in hipaa_lines:
        keywords = clause.replace('(', '').replace(')', '').split()
        if any(word in text for word in keywords):
            required_matches += 1

    score = (required_matches / len(hipaa_lines)) * 100
    return score >= 40  # Adjust threshold if needed

# Add Policy View

@login_required
def add_policy(request):
    if request.method == 'POST':
        form = PolicyForm(request.POST, request.FILES)
        standard_path = os.path.join(os.path.dirname(__file__), '..', 'hipaa_standards.txt')
        
        if form.is_valid():
            title = form.cleaned_data.get('title')
            text = form.cleaned_data.get('text')
            uploaded_file = form.cleaned_data.get('file')

            final_text = ""
            if uploaded_file:
                final_text = read_file_content(uploaded_file)
            elif text:
                final_text = text

            is_compliant = check_hipaa_compliance(final_text, standard_path)

            if not is_compliant:
                messages.warning(request, "This policy may not meet HIPAA standards.")
            else:
                policy = form.save(commit=False)
                policy.text = final_text
                policy.author = request.user  # ✅ Assign logged-in user
                if not title:
                    policy.title = uploaded_file.name if uploaded_file else "Untitled Policy"
                policy.save()
                messages.success(request, "Policy successfully added.")
    else:
        form = PolicyForm()

    policies = Policy.objects.all().order_by('-created_at')
    return render(request, 'policy.html', {'form': form, 'policies': policies})

# View Policy
@login_required
def policy_view(request, pk):
    policy = Policy.objects.get(pk=pk)
    return render(request, 'policy.html', {'policy': policy})

from django.shortcuts import get_object_or_404

def view_policy(request, pk):
    policy = get_object_or_404(Policy, pk=pk)
    return render(request, 'view_policy.html', {'policy': policy})



# login 
from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib import messages

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')  # using 'username', not 'email'
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect('dashboard')  # or use the actual name used in your URLconf
        else:
            messages.error(request, "Invalid login credentials")
            return redirect('login')  # fallback to the login page

    return render(request, 'core/login.html')  # GET request

@login_required
def dashboard(request):
    return render(request, 'core/dashboard.html')

#dashboard view
from django.shortcuts import render, redirect
from .forms import SurveyForm
from .models import SurveyResponse


def dashboard_view(request):
    score = None
    message = ""
    rotation = 0 # default
    if request.method == 'POST':
        form = SurveyForm(request.POST)
        if form.is_valid():
            q1 = form.cleaned_data['q1']
            q2 = form.cleaned_data['q2']
            q3 = form.cleaned_data['q3']
            q4 = form.cleaned_data['q4']

            yes_count = sum([q == 'yes' for q in [q1, q2, q3, q4]])
            score = (yes_count / 4) * 100

            # Save the data to DB
            SurveyResponse.objects.create(
                q1=q1, q2=q2, q3=q3, q4=q4, score=score
            )
        
            # Score message
        if score is not None:
            if score == 100:
                message = "Excellent!"
                rotation = 65 #green zone
            elif score >= 75:
                message = "Nice Work!"
                rotation = 10  # Between Yellow & Green
            elif score >= 50:
                message = "Need to Work On"
                rotation = 0  # between Yesllow & green zone

            else: 
              if score == 0:
                message = "Critical"
                rotation = -30   # Red zone

    else:
        form = SurveyForm()

    return render(request, 'dashboard.html', {
        'form': form,
        'score': score,
        'feedback': message,
        'rotation': rotation,
    })

#incident report
from django.shortcuts import render, redirect
from .forms import IncidentReportForm

def incident_report_view(request):
    if request.method == 'POST':
        form = IncidentReportForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, 'incident.html', {'form': IncidentReportForm(), 'success': True})
    else:
        form = IncidentReportForm()
    return render(request, 'incident.html', {'form': form})

#training
from django.shortcuts import render
from .forms import TrainingQuizForm
from .models import QuizSubmission

def training_view(request):
    score = None
    certified = False
    form = TrainingQuizForm()

    if request.method == 'POST':
        form = TrainingQuizForm(request.POST)
        if form.is_valid():
            answers = [form.cleaned_data['q1'], form.cleaned_data['q2'], form.cleaned_data['q3']]
            correct_answers = ['yes', 'no', 'yes']
            score = sum(1 for i in range(3) if answers[i] == correct_answers[i]) * 10  # 10 per question
            certified = score >= 20  # Certification condition

            # Save result
            QuizSubmission.objects.create(
                name=form.cleaned_data['name'],
                score=score
            )

    return render(request, 'training.html', {
        'form': form,
        'score': score,
        'certified': certified
    })
    
 #certification for training part
from django.shortcuts import render

def certification_view(request):
    score = request.GET.get('score', None)
    return render(request, 'certification.html', {'score': score})

#logout 
from django.contrib.auth import logout
from django.shortcuts import redirect

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')  # Make sure 'login' is the name of your login URL
