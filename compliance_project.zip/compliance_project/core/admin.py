
# Register your models here.
from django.contrib import admin
from .models import CustomUser, Policy
from .models import Policy, SurveyResponse
from .models import IncidentReport

admin.site.register(CustomUser)
admin.site.register(Policy)
admin.site.register(SurveyResponse)
admin.site.register(IncidentReport)